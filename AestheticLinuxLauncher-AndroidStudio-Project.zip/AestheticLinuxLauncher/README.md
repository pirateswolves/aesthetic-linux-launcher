# Aesthetic Linux Launcher (starter project)

A lightweight Android HOME launcher with a dark, Linux-inspired mobile workspace.
It does not root the phone or replace Android. It is an ordinary launcher app.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select the `app` run configuration and install to the Moto G35.
4. Press Home and select **Aesthetic Linux**. Choose **Always** only after testing.

## Current features
- Registers as an Android HOME launcher.
- Dark desktop-style home screen with live clock/date.
- Lists installed launchable apps with their icons and opens them on tap.
- Menu offers refresh, Android Home settings, and About.

## Notes
- This is source code, not a precompiled APK.
- Android Studio/Android SDK is required to build the APK.
- The launcher intentionally does not request root access or change system files.
- Search field is currently a visual placeholder; deeper launcher features can be added in later versions.
