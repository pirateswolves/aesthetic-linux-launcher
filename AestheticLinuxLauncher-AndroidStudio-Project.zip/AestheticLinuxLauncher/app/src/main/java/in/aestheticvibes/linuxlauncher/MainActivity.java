package in.aestheticvibes.linuxlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, appGrid;
    private TextView clock, date;
    private final int bg = Color.rgb(14, 19, 29);
    private final int panel = Color.rgb(25, 33, 47);
    private final int accent = Color.rgb(255, 142, 65);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(Color.rgb(10, 14, 22));
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        updateClock();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(14));
        root.setBackgroundColor(bg);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("◉  AESTHETIC LINUX", 13, accent, true);
        root.addView(brand);

        clock = text("--:--", 42, Color.WHITE, true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(22);
        root.addView(clock, cp);

        date = text("", 14, 0xFFADB8C8, false);
        root.addView(date);

        TextView subtitle = text("YOUR MOBILE WORKSPACE", 11, 0xFF7F8DA3, true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(24); sp.bottomMargin = dp(12);
        root.addView(subtitle, sp);

        LinearLayout quick = new LinearLayout(this);
        quick.setGravity(Gravity.CENTER_VERTICAL);
        quick.setPadding(dp(14), dp(12), dp(14), dp(12));
        quick.setBackground(shape(panel, dp(18)));
        TextView search = text("⌕   Find an application", 15, 0xFFDCE4EF, false);
        quick.addView(search, new LinearLayout.LayoutParams(0, -2, 1));
        TextView menu = text("⋮", 24, accent, true);
        quick.addView(menu);
        menu.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Aesthetic Linux")
                .setItems(new String[]{"Refresh applications", "Android home settings", "About"}, (d, which) -> {
                    if (which == 0) populateApps();
                    else if (which == 1) {
                        Intent i = new Intent("android.settings.HOME_SETTINGS");
                        try { startActivity(i); } catch (Exception ignored) {}
                    } else new AlertDialog.Builder(this).setMessage("A lightweight Linux-inspired Android home launcher. No root required.").setPositiveButton("OK", null).show();
                }).show());
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
        qp.bottomMargin = dp(22);
        root.addView(quick, qp);

        TextView appsTitle = text("APPLICATIONS", 12, 0xFF9BAAC0, true);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.bottomMargin = dp(12);
        root.addView(appsTitle, ap);

        appGrid = new LinearLayout(this);
        appGrid.setOrientation(LinearLayout.VERTICAL);
        root.addView(appGrid);

        TextView footer = text("●  DESKTOP MODE     •     ANDROID CORE", 10, 0xFF68788F, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(28);
        root.addView(footer, fp);
        populateApps();
    }

    private void populateApps() {
        appGrid.removeAllViews();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ApplicationInfo> apps = new ArrayList<>();
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(query, 0)) {
            if (ri.activityInfo == null) continue;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(ri.activityInfo.packageName, 0);
                if (!apps.contains(ai)) apps.add(ai);
            } catch (Exception ignored) {}
        }
        Collections.sort(apps, (a,b) -> pm.getApplicationLabel(a).toString()
                .compareToIgnoreCase(pm.getApplicationLabel(b).toString()));

        int columns = 4;
        for (int start = 0; start < apps.size(); start += columns) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.TOP);
            for (int j = start; j < Math.min(start + columns, apps.size()); j++) {
                ApplicationInfo ai = apps.get(j);
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(dp(3), dp(10), dp(3), dp(12));
                ImageView icon = new ImageView(this);
                try { icon.setImageDrawable(pm.getApplicationIcon(ai)); } catch (Exception ignored) {}
                LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(44), dp(44));
                cell.addView(icon, ip);
                TextView label = text(pm.getApplicationLabel(ai).toString(), 10, 0xFFE5EAF2, false);
                label.setGravity(Gravity.CENTER);
                label.setMaxLines(2);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(32));
                lp.topMargin = dp(6);
                cell.addView(label, lp);
                cell.setOnClickListener(v -> {
                    Intent launch = pm.getLaunchIntentForPackage(ai.packageName);
                    if (launch != null) startActivity(launch);
                });
                row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
            }
            while (row.getChildCount() < columns) row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
            appGrid.addView(row);
        }
        if (apps.isEmpty()) {
            TextView empty = text("No launchable apps found.", 14, Color.WHITE, false);
            appGrid.addView(empty);
        }
    }

    private void updateClock() {
        String time = new SimpleDateFormat("h:mm", java.util.Locale.getDefault()).format(new Date());
        String day = new SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault()).format(new Date());
        clock.setText(time);
        date.setText(day);
        clock.postDelayed(this::updateClock, 30000);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
